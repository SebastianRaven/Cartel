﻿using Twilio.Types;

namespace AirTNG.Web.Domain.Reservations
{
    public class Notification
    {
        public string From { get; set; }
        public string To { get; set; }
        public string Messsage { get; set; }
    }
}
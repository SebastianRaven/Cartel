﻿namespace AirTNG.Web.Models
{
    public enum ReservationStatus
    {
        Pending,
        Confirmed,
        Rejected
    }
}